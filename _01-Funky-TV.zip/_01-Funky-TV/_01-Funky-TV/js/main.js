/******************/
/*  Feature Dev   */
/******************/
/* JS allows you to create an experience.
/* Sound button
/* Two buttons- two channels.  
/* Change channel, load animated .gif
/* We've been looking for you, Neo...     */